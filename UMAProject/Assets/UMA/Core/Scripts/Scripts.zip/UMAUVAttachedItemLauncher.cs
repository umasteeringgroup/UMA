#define USING_BAKEMESH
using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UMA;
using UMA.CharacterSystem;
using Unity.Collections;
using UnityEngine;


namespace UMA
{
    public class UMAUVAttachedItemLauncher : MonoBehaviour
    {
        // TODO:
        // Should take an array of UV, and save an array of vertex indexes.
        // and a array of prefabs...

        public DynamicCharacterAvatar avatar;
        public Vector2 uVLocation;
        public string slotName;
        public Quaternion rotation;
        public Vector3 normalAdjust;
        public Vector3 translation;
        public GameObject prefab;
        public string boneName;

        private GameObject prefabInstance;
        public int VertexNumber;
        public int subMeshNumber;
        public List<int> triangle = new List<int>();
        public SkinnedMeshRenderer skin;
        private Mesh tempMesh;
        private bool componentAdded = false;
        private UMAUVAttachedItem bootStrapper;
        private UMAData umaData;
        private Transform mostestBone;
        


        public bool worldTransform;

        public void Start()
        {
            Debug.Log($"Start {GetInstanceID()}");
        }


        public void OnDnaAppliedBootstrapper(UMAData umaData)
        {
            Debug.Log($"DNA Applied {GetInstanceID()}");
            var uva = umaData.gameObject.GetComponent<UMAUVAttachedItem>();

            if (!uva)
            {
                Debug.Log($"Adding object {GetInstanceID()}");
                componentAdded = true;
                uva = umaData.gameObject.AddComponent<UMAUVAttachedItem>();
                
                uva.Setup(umaData, this);
            }
        }


        public void OnDestroy()
        {
            Debug.Log($"Destroy {GetInstanceID()}");
           if (gameObject != null)
            {
                Debug.Log($"Destroying Item {GetInstanceID()}");
                var uva = gameObject.GetComponent<UMAUVAttachedItem>();
                DestroyImmediate(uva);
            }
        }
    }
}

