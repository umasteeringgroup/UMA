#define USING_BAKEMESH
using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UMA;
using UMA.CharacterSystem;
using Unity.Collections;
using UnityEngine;


namespace UMA
{
    public class UMAUVAttachedItem : MonoBehaviour
    {
        // TODO:
        // Should take an array of UV, and save an array of vertex indexes.
        // and a array of prefabs...

        public DynamicCharacterAvatar avatar;
        public Vector2 uVLocation;
        public string slotName;
        public Quaternion rotation;
        public Vector3 normalAdjust;
        public Vector3 translation;
        public GameObject prefab;
        public string boneName;

        private GameObject prefabInstance;
        public int VertexNumber;
        public int subMeshNumber;
        public List<int> triangle = new List<int>();
        public SkinnedMeshRenderer skin;
        private Mesh tempMesh;
        private bool componentAdded = false;
        private UMAUVAttachedItemLauncher bootStrapper;
        private UMAData umaData;
        private Transform mostestBone;
        
        private struct BonesAndWeights
        {
            public Transform Bone;
            public float Weight;
            public Vector3 Normal;
        }

        private List<BonesAndWeights> weights;

#if !USING_BAKEMESH
    // Only used when not baking mesh
    private Matrix4x4[] boneMatrices;
    private BoneWeight[] meshBoneWeights;
    private Matrix4x4[] meshBindposes; 
    private Transform[] skinnedBones; 
    private Vector3 UntransformedPosition;
    private Vector3 UntransformedNormal;
#endif
        public bool worldTransform;

        public void Start()
        {
            Debug.Log($"Start {GetInstanceID()}");
        }


        public void OnDestroy()
        {
            Debug.Log($"Destroy {GetInstanceID()}");
           if (gameObject != null)
            {
                Debug.Log($"Destroying Item {GetInstanceID()}");
                var uva = gameObject.GetComponent<UMAUVAttachedItem>();
                DestroyImmediate(uva);
            }
        }

        public void OnEnable()
        {
            Debug.Log($"Enable {GetInstanceID()}");
        }
        public void OnDisable()
        {
            Debug.Log($"Disable {GetInstanceID()}");
        }

        public void Setup(UMAData umaData, UMAUVAttachedItemLauncher bootstrap)
        {
            if (tempMesh == null)
            {
                tempMesh = new Mesh();
                VertexNumber = -1;
                subMeshNumber = -1;
                avatar = umaData.GetComponent<DynamicCharacterAvatar>();
                avatar.CharacterUpdated.AddListener(UMAUpdated);
                bootStrapper = bootstrap;

                normalAdjust = bootstrap.normalAdjust;
                uVLocation = bootstrap.uVLocation;
                slotName = bootstrap.slotName;
                rotation = bootstrap.rotation;
                translation = bootstrap.translation;
                prefab = bootstrap.prefab;
                boneName = bootstrap.boneName;
                this.umaData = umaData;
            }
        }

        public void UMAUpdated(UMAData umaData)
        {
            // find the slot in the recipe.
            // find the overlay in the recipe
            // calculate the new UV coordinates (in case it changed).
            // Loop through the vertexes, and find the one with the closest UV.
            Debug.Log("UMAUpdated in Attached Item.");
            skin = umaData.GetRenderer(0);
#if !USING_BAKEMESH
        boneMatrices = new Matrix4x4[skin.bones.Length];
#endif
            foreach (var slotData in umaData.umaRecipe.slotDataList)
            {
                if (slotData != null)
                {
                    if (slotData.slotName == slotName)
                    {
                        ProcessSlot(umaData, slotData);
                        break;
                    }
                }
            }
            if (prefabInstance == null)
            {
                Debug.Log("Creating prefab");
                prefabInstance = Instantiate(prefab,umaData.gameObject.transform);
                UMAUVAttachedItem umaUV = prefabInstance.GetComponent<UMAUVAttachedItem>();
                if (umaUV)
                {
                    umaUV.slotName = slotName;
                    umaUV.VertexNumber = VertexNumber;
                    umaUV.triangle.Clear();
                    umaUV.triangle.AddRange(triangle);
                    umaUV.subMeshNumber = subMeshNumber;
                    umaUV.avatar = avatar;
                    umaUV.prefabInstance = prefabInstance;
                }
            }
        }

        private void ProcessSlot(UMAData umaData, SlotData slotData)
        {
            Debug.Log($"Processing slot {slotData.slotName}");
            Vector2 UVInAtlas = slotData.ConvertToAtlasUV(uVLocation);
            SkinnedMeshRenderer smr = umaData.GetRenderer(slotData.skinnedMeshRenderer);

            Mesh mesh = smr.sharedMesh;
            subMeshNumber = slotData.submeshIndex;
            var smd = mesh.GetSubMesh(subMeshNumber);
            int maxVert = slotData.asset.meshData.vertexCount + slotData.vertexOffset;
#if !USING_BAKEMESH
            meshBoneWeights = mesh.boneWeights;
#endif
            using (var dataArray = Mesh.AcquireReadOnlyMeshData(mesh))
            {
                
                Mesh.MeshData dat = dataArray[0];
                var allUVS = new NativeArray<Vector2>(mesh.vertexCount, Allocator.Temp);
                var allNormals = new NativeArray<Vector3>(mesh.vertexCount, Allocator.Temp);
                var allVerts = new NativeArray<Vector3>(mesh.vertexCount, Allocator.Temp);

                dat.GetUVs(0, allUVS);
                dat.GetNormals(allNormals);
                dat.GetVertices(allVerts);
                VertexNumber = FindVert(slotData, maxVert, UVInAtlas, allUVS);
                Debug.Log($"Found vertex {VertexNumber}");
                triangle = FindTriangle(VertexNumber,dat,mesh);
#if USING_BONEWEIGHTS
                weights = GetBoneWeights(VertexNumber, mesh, smr);
#else
                mostestBone = GetMostestBone(VertexNumber, mesh, smr);
#endif


#if !USING_BAKEMESH
            UntransformedNormal = allNormals[VertexNumber];
            UntransformedPosition = allVerts[VertexNumber];
#endif
            }
        }

        private List<int> FindTriangle(int vert, Mesh.MeshData dat, Mesh mesh)
        {
            var f = dat.indexFormat;


            for (int i = 0; i < dat.subMeshCount; i++)
            {
                var mt = mesh.GetTopology(i);

                if (mt != MeshTopology.Triangles)
                {
                    continue;
                }
                var submesh = dat.GetSubMesh(i);
                var count = submesh.indexCount;

                var subIndices = new NativeArray<int>(count,Allocator.Temp);
                dat.GetIndices(subIndices, i);
                for(int j = 0; j < count; j+= 3)
                {
                    if (subIndices[j] == vert || subIndices[j+1] == vert || subIndices[j+2] == vert)
                    {
                        var tri = new List<int>(3);
                        tri.Add(subIndices[j]);
                        tri.Add(subIndices[j + 1]);
                        tri.Add(subIndices[j + 2]);
                        return tri;
                    }
                }
            }
            return new List<int>();
        }

        private Transform GetMostestBone(int vertexNumber, Mesh mesh, SkinnedMeshRenderer smr)
        {
            var weights = new List<BonesAndWeights>();
            var meshweights = mesh.GetAllBoneWeights();
            var meshbpv = mesh.GetBonesPerVertex();

            int myOffset = 0;

            // find the beginning of the bone
            for (int i = 0; i < vertexNumber; i++)
            {
                myOffset += meshbpv[i];
            }
            Transform mostestBone = smr.bones[meshweights[myOffset].boneIndex];

            Debug.Log($"Vertex {vertexNumber} Offset = {myOffset} in BoneWeights Mostest Bone = {mostestBone.gameObject.name}");
            return mostestBone;
        }

        private List<BonesAndWeights> GetBoneWeights(int vertexNumber, Mesh mesh, SkinnedMeshRenderer smr)
        {
            var weights = new List<BonesAndWeights>();
            var meshweights = mesh.GetAllBoneWeights();
            var meshbpv = mesh.GetBonesPerVertex();

            int myOffset = 0;

            // find the beginning of the bone
            for (int i = 0; i < vertexNumber; i++)
            {
                myOffset += meshbpv[i];
            }

            Debug.Log($"Vertex {vertexNumber} Offset = {myOffset} in BoneWeights");
            for(int i=myOffset; i < myOffset + meshbpv[vertexNumber]; i++)
            {
                BonesAndWeights boneWeights = new BonesAndWeights();
                boneWeights.Bone = smr.bones[meshweights[i].boneIndex];
                boneWeights.Weight = meshweights[i].weight;
                weights.Add(boneWeights);
            }
            Debug.Log($"weights size = {weights.Count}");
            return weights;
        }

        private int FindVert(SlotData slotData, int maxVert, Vector2 UV, NativeArray<Vector2> allUVS)
        {
            int v = slotData.vertexOffset;
            float shortestDistance = Mathf.Abs((allUVS[slotData.vertexOffset] - UV).magnitude);
            for (int i = slotData.vertexOffset + 1; i < maxVert; i++)
            {
                float thisDist = Mathf.Abs((allUVS[i] - UV).magnitude);
                if (thisDist < shortestDistance)
                {
                    v = i;
                    shortestDistance = thisDist;
                }
            }

            return v;
        }

        void LateUpdate()
        {
            if (avatar != null && prefabInstance != null && VertexNumber >= 0 && subMeshNumber >= 0)
            {
                Vector3 position;
                Vector3 normal;

#if USING_BAKEMESH
                skin.BakeMesh(tempMesh);
                using (var dataArray = Mesh.AcquireReadOnlyMeshData(tempMesh))
                {
                    var data = dataArray[0];
                    var allVerts = new NativeArray<Vector3>(tempMesh.vertexCount, Allocator.Temp);
                    data.GetVertices(allVerts);
                    var allNormals = new NativeArray<Vector3>(tempMesh.vertexCount, Allocator.Temp);
                    data.GetNormals(allNormals);
                    position = allVerts[VertexNumber];
                    normal = allNormals[VertexNumber];

#else
                for (int i = 0; i < boneMatrices.Length; i++)
                {
                    boneMatrices[i] = skinnedBones[i].localToWorldMatrix * meshBindposes[i];
                }

                BoneWeight weight;
                Matrix4x4 bm0;
                Matrix4x4 bm1;
                Matrix4x4 bm2;
                Matrix4x4 bm3;
                Matrix4x4 vm = new Matrix4x4();
                
                weight = meshBoneWeights[VertexNumber];
                bm0 = boneMatrices[weight.boneIndex0];
                bm1 = boneMatrices[weight.boneIndex1];
                bm2 = boneMatrices[weight.boneIndex2];
                bm3 = boneMatrices[weight.boneIndex3];

                vm.m00 = bm0.m00 * weight.weight0 + bm1.m00 * weight.weight1 + bm2.m00 * weight.weight2 + bm3.m00 * weight.weight3;
                vm.m01 = bm0.m01 * weight.weight0 + bm1.m01 * weight.weight1 + bm2.m01 * weight.weight2 + bm3.m01 * weight.weight3;
                vm.m02 = bm0.m02 * weight.weight0 + bm1.m02 * weight.weight1 + bm2.m02 * weight.weight2 + bm3.m02 * weight.weight3;
                vm.m03 = bm0.m03 * weight.weight0 + bm1.m03 * weight.weight1 + bm2.m03 * weight.weight2 + bm3.m03 * weight.weight3;

                vm.m10 = bm0.m10 * weight.weight0 + bm1.m10 * weight.weight1 + bm2.m10 * weight.weight2 + bm3.m10 * weight.weight3;
                vm.m11 = bm0.m11 * weight.weight0 + bm1.m11 * weight.weight1 + bm2.m11 * weight.weight2 + bm3.m11 * weight.weight3;
                vm.m12 = bm0.m12 * weight.weight0 + bm1.m12 * weight.weight1 + bm2.m12 * weight.weight2 + bm3.m12 * weight.weight3;
                vm.m13 = bm0.m13 * weight.weight0 + bm1.m13 * weight.weight1 + bm2.m13 * weight.weight2 + bm3.m13 * weight.weight3;

                vm.m20 = bm0.m20 * weight.weight0 + bm1.m20 * weight.weight1 + bm2.m20 * weight.weight2 + bm3.m20 * weight.weight3;
                vm.m21 = bm0.m21 * weight.weight0 + bm1.m21 * weight.weight1 + bm2.m21 * weight.weight2 + bm3.m21 * weight.weight3;
                vm.m22 = bm0.m22 * weight.weight0 + bm1.m22 * weight.weight1 + bm2.m22 * weight.weight2 + bm3.m22 * weight.weight3;
                vm.m23 = bm0.m23 * weight.weight0 + bm1.m23 * weight.weight1 + bm2.m23 * weight.weight2 + bm3.m23 * weight.weight3;

                position = vm.MultiplyPoint3x4(UntransformedPosition);
                normal = vm.MultiplyVector(UntransformedNormal).normalized;
#endif

                    if (worldTransform)
                    {
                        position = transform.TransformPoint(position);
                        normal = transform.TransformDirection(normal).normalized;
                        prefabInstance.transform.position = position;
                        prefabInstance.transform.rotation = Quaternion.Euler(normal);
                    } 
                    else
                    {
#if USING_BONEWEIGHTS
                        Vector3 newNormal = Vector3.zero;
                        for (int i = 0; i < weights.Count; i++)
                        {
                            BonesAndWeights b = weights[i];
                            newNormal += (b.Bone.TransformDirection(normal) * b.Weight);
                        }
#else
                        if (triangle.Count > 0)
                        {

                            Plane plane = new Plane(allVerts[triangle[0]], allVerts[triangle[1]], allVerts[triangle[2]]);
                            prefabInstance.transform.localPosition = position + (translation.x * plane.normal);
                            prefabInstance.transform.localRotation = Quaternion.LookRotation((plane.normal + normalAdjust).normalized);// * rotation;
                        }
                        else
                        {
                            Vector3 newNormal = Vector3.Normalize(mostestBone.position - position);
                            // Vector3 newNormal = normal;                            
                            prefabInstance.transform.localPosition = position;
                            prefabInstance.transform.localRotation = Quaternion.LookRotation(newNormal);
                        }

#endif
                    }
                }
                return;
            }
        }
    }
}

